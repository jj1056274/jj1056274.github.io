<!DOCTYPE html>
<html lang="pt-BR" prefix="og: http://ogp.me/ns#">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="http://gmpg.org/xfn/11" />
		<link rel="pingback" href="https://appdindin.com.br/wp/xmlrpc.php" />
		<title>Page not found - DinDin</title>

<!-- This site is optimized with the Yoast SEO plugin v5.9.3 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="pt_BR" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - DinDin" />
<meta property="og:site_name" content="DinDin" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="Page not found - DinDin" />
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/appdindin.com.br\/blog\/","name":"DinDin","potentialAction":{"@type":"SearchAction","target":"https:\/\/appdindin.com.br\/blog\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Feed para DinDin &raquo;" href="https://appdindin.com.br/blog/feed/" />
<link rel="alternate" type="application/rss+xml" title="Feed de comentários para DinDin &raquo;" href="https://appdindin.com.br/blog/comments/feed/" />
<!-- This site uses the Google Analytics by MonsterInsights plugin v6.2.6 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
		var disableStr = 'ga-disable-UA-87957399-1';

	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

	__gaTracker('create', 'UA-87957399-1', 'auto');
	__gaTracker('set', 'forceSSL', true);
	__gaTracker('require', 'displayfeatures');
	__gaTracker('require', 'linkid', 'linkid.js');
	__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
</script>
<!-- / Google Analytics by MonsterInsights -->
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/appdindin.com.br\/wp\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.1"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56794,8205,9794,65039],[55358,56794,8203,9794,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='colormag_google_fonts-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A400%2C600&#038;ver=4.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='colormag_style-css'  href='https://appdindin.com.br/wp/wp-content/themes/colormag/style.css?ver=4.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='colormag-fontawesome-css'  href='https://appdindin.com.br/wp/wp-content/themes/colormag/fontawesome/css/font-awesome.css?ver=4.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='colormag-featured-image-popup-css-css'  href='https://appdindin.com.br/wp/wp-content/themes/colormag/js/magnific-popup/magnific-popup.css?ver=20150310' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","is_debug_mode":"false","download_extensions":"doc,exe,js,pdf,ppt,tgz,zip,xls","inbound_paths":"","home_url":"https:\/\/appdindin.com.br\/blog","track_download_as":"event","internal_label":"int","hash_tracking":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend.min.js?ver=6.2.6'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/colormag-custom.js?ver=4.9.1'></script>
<!--[if lte IE 8]>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/html5shiv.min.js?ver=4.9.1'></script>
<![endif]-->
<link rel='https://api.w.org/' href='https://appdindin.com.br/blog/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://appdindin.com.br/wp/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://appdindin.com.br/wp/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.1" />
<link rel="icon" href="https://appdindin.com.br/wp/wp-content/uploads/2017/10/dindin-logo-150.png" sizes="32x32" />
<link rel="icon" href="https://appdindin.com.br/wp/wp-content/uploads/2017/10/dindin-logo-150.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://appdindin.com.br/wp/wp-content/uploads/2017/10/dindin-logo-150.png" />
<meta name="msapplication-TileImage" content="https://appdindin.com.br/wp/wp-content/uploads/2017/10/dindin-logo-150.png" />
<!-- DinDin Internal Styles --><style type="text/css"> .colormag-button,blockquote,button,input[type=reset],input[type=button],input[type=submit],#masthead.colormag-header-clean #site-navigation.main-small-navigation .menu-toggle{background-color:#007079}#site-title a,.next a:hover,.previous a:hover,.social-links i.fa:hover,a,#masthead.colormag-header-clean .social-links li:hover i.fa,#masthead.colormag-header-classic .social-links li:hover i.fa,#masthead.colormag-header-clean .breaking-news .newsticker a:hover,#masthead.colormag-header-classic .breaking-news .newsticker a:hover,#masthead.colormag-header-classic #site-navigation .fa.search-top:hover,#masthead.colormag-header-classic #site-navigation.main-navigation .random-post a:hover .fa-random{color:#007079}.fa.search-top:hover,#masthead.colormag-header-classic #site-navigation.main-small-navigation .menu-toggle{background-color:#007079}#site-navigation{border-top:4px solid #007079}.home-icon.front_page_on,.main-navigation a:hover,.main-navigation ul li ul li a:hover,.main-navigation ul li ul li:hover>a,.main-navigation ul li.current-menu-ancestor>a,.main-navigation ul li.current-menu-item ul li a:hover,.main-navigation ul li.current-menu-item>a,.main-navigation ul li.current_page_ancestor>a,.main-navigation ul li.current_page_item>a,.main-navigation ul li:hover>a,.main-small-navigation li a:hover,.site-header .menu-toggle:hover,#masthead.colormag-header-classic #site-navigation.main-navigation ul#menu-primary ul.sub-menu li:hover > a, #masthead.colormag-header-classic #site-navigation.main-navigation ul#menu-primary ul.sub-menu li.current-menu-ancestor > a, #masthead.colormag-header-classic #site-navigation.main-navigation ul#menu-primary ul.sub-menu li.current-menu-item > a,#masthead .main-small-navigation li:hover > a, #masthead .main-small-navigation li.current-page-ancestor > a, #masthead .main-small-navigation li.current-menu-ancestor > a, #masthead .main-small-navigation li.current-page-item > a, #masthead .main-small-navigation li.current-menu-item > a{background-color:#007079}.main-small-navigation .current-menu-item>a,.main-small-navigation .current_page_item>a{background:#007079}#masthead.colormag-header-classic #site-navigation.main-navigation ul#menu-primary > li:hover > a, #masthead.colormag-header-classic #site-navigation.main-navigation ul#menu-primary > li.current-menu-item > a, #masthead.colormag-header-classic #site-navigation.main-navigation ul#menu-primary > li.current-menu-ancestor > a,#masthead.colormag-header-classic #site-navigation.main-navigation ul#menu-primary ul.sub-menu li:hover, #masthead.colormag-header-classic #site-navigation.main-navigation ul#menu-primary ul.sub-menu li.current-menu-ancestor, #masthead.colormag-header-classic #site-navigation.main-navigation ul#menu-primary ul.sub-menu li.current-menu-item,#masthead.colormag-header-classic #site-navigation.main-small-navigation .menu-toggle,#masthead.colormag-header-classic #site-navigation .menu-toggle:hover{border-color:#007079}.promo-button-area a:hover{border:2px solid #007079;background-color:#007079}#content .wp-pagenavi .current,#content .wp-pagenavi a:hover,.format-link .entry-content a,.pagination span{background-color:#007079}.pagination a span:hover{color:#007079;border-color:#007079}#content .comments-area a.comment-edit-link:hover,#content .comments-area a.comment-permalink:hover,#content .comments-area article header cite a:hover,.comments-area .comment-author-link a:hover{color:#007079}.comments-area .comment-author-link span{background-color:#007079}.comment .comment-reply-link:hover,.nav-next a,.nav-previous a{color:#007079}#secondary .widget-title{border-bottom:2px solid #007079}#secondary .widget-title span{background-color:#007079}.footer-widgets-area .widget-title{border-bottom:2px solid #007079}.footer-widgets-area .widget-title span,.colormag-footer--classic .footer-widgets-area .widget-title span::before{background-color:#007079}.footer-widgets-area a:hover{color:#007079}.advertisement_above_footer .widget-title{border-bottom:2px solid #007079}.advertisement_above_footer .widget-title span{background-color:#007079}a#scroll-up i{color:#007079}.page-header .page-title{border-bottom:2px solid #007079}#content .post .article-content .above-entry-meta .cat-links a,.page-header .page-title span{background-color:#007079}#content .post .article-content .entry-title a:hover,.entry-meta .byline i,.entry-meta .cat-links i,.entry-meta a,.post .entry-title a:hover,.search .entry-title a:hover{color:#007079}.entry-meta .post-format i{background-color:#007079}.entry-meta .comments-link a:hover,.entry-meta .edit-link a:hover,.entry-meta .posted-on a:hover,.entry-meta .tag-links a:hover,.single #content .tags a:hover{color:#007079}.more-link,.no-post-thumbnail{background-color:#007079}.post-box .entry-meta .cat-links a:hover,.post-box .entry-meta .posted-on a:hover,.post.post-box .entry-title a:hover{color:#007079}.widget_featured_slider .slide-content .above-entry-meta .cat-links a{background-color:#007079}.widget_featured_slider .slide-content .below-entry-meta .byline a:hover,.widget_featured_slider .slide-content .below-entry-meta .comments a:hover,.widget_featured_slider .slide-content .below-entry-meta .posted-on a:hover,.widget_featured_slider .slide-content .entry-title a:hover{color:#007079}.widget_highlighted_posts .article-content .above-entry-meta .cat-links a{background-color:#007079}.byline a:hover,.comments a:hover,.edit-link a:hover,.posted-on a:hover,.tag-links a:hover,.widget_highlighted_posts .article-content .below-entry-meta .byline a:hover,.widget_highlighted_posts .article-content .below-entry-meta .comments a:hover,.widget_highlighted_posts .article-content .below-entry-meta .posted-on a:hover,.widget_highlighted_posts .article-content .entry-title a:hover{color:#007079}.widget_featured_posts .article-content .above-entry-meta .cat-links a{background-color:#007079}.widget_featured_posts .article-content .entry-title a:hover{color:#007079}.widget_featured_posts .widget-title{border-bottom:2px solid #007079}.widget_featured_posts .widget-title span{background-color:#007079}.related-posts-main-title .fa,.single-related-posts .article-content .entry-title a:hover{color:#007079}@media (max-width: 768px) {.better-responsive-menu .sub-toggle{background-color:#00525b}}</style>
	</head>

	<body class="error404 wp-custom-logo ">
				<div id="page" class="hfeed site">
			
			
			<header id="masthead" class="site-header clearfix ">
				<div id="header-text-nav-container" class="clearfix">

								<div class="news-bar">
				<div class="inner-wrap clearfix">
						<div class="date-in-header">
		terça-feira, dezembro 19, 2017	</div>

					   <div class="breaking-news">
      <strong class="breaking-news-latest">Últimos:</strong>
      <ul class="newsticker">
               <li>
            <a href="https://appdindin.com.br/blog/amigo-secreto-dicas-para-nao-fazer-feio/" title="Amigo secreto de fim de ano: dicas para não fazer feio">Amigo secreto de fim de ano: dicas para não fazer feio</a>
         </li>
               <li>
            <a href="https://appdindin.com.br/blog/quais-as-maiores-franquias-de-alimentos-no-brasil/" title="Quais são as maiores franquias de alimentos no Brasil">Quais são as maiores franquias de alimentos no Brasil</a>
         </li>
               <li>
            <a href="https://appdindin.com.br/blog/melhores-cortes-para-churrasco/" title="Melhores cortes para churrasco">Melhores cortes para churrasco</a>
         </li>
               <li>
            <a href="https://appdindin.com.br/blog/7-destinos-brasileiros-preferidos-dos-turistas/" title="10 Destinos brasileiros preferidos dos turistas">10 Destinos brasileiros preferidos dos turistas</a>
         </li>
               <li>
            <a href="https://appdindin.com.br/blog/dicas-para-viagem-como-organizar-a-mala/" title="Dicas para viagem: como organizar a mala?">Dicas para viagem: como organizar a mala?</a>
         </li>
            </ul>
   </div>
   
							<div class="social-links clearfix">
			<ul>
				<li><a href="https://www.facebook.com/aplicativodindin/" target="_blank"><i class="fa fa-facebook"></i></a></li><li><a href="https://twitter.com/appdindin" target="_blank"><i class="fa fa-twitter"></i></a></li><li><a href="https://www.appdindin.com.br/" target="_blank"><i class="fa fa-google mais"></i></a></li><li><a href="https://www.instagram.com/appdindin/" target="_blank"><i class="fa fa-instagram"></i></a></li><li><a href="https://www.appdindin.com.br/" target="_blank"><i class="fa fa-pinterest"></i></a></li><li><a href="https://www.appdindin.com.br/" target="_blank"><i class="fa fa-youtube"></i></a></li>			</ul>
		</div><!-- .social-links -->
						</div>
			</div>
			
					
					
		<div class="inner-wrap">

			<div id="header-text-nav-wrap" class="clearfix">
				<div id="header-left-section">
											<div id="header-logo-image">
							
							<a href="https://appdindin.com.br/blog/" class="custom-logo-link" rel="home" itemprop="url"><img width="155" height="125" src="https://appdindin.com.br/wp/wp-content/uploads/2017/11/icon.png" class="custom-logo" alt="DinDin" itemprop="logo" /></a>						</div><!-- #header-logo-image -->
											<div id="header-text" class="screen-reader-text">
													<h3 id="site-title">
								<a href="https://appdindin.com.br/blog/" title="DinDin" rel="home">DinDin</a>
							</h3>
																			<p id="site-description">O DinDin permite pagar e cobrar seus amigos com facilidade!</p>
						<!-- #site-description -->
					</div><!-- #header-text -->
				</div><!-- #header-left-section -->
				<div id="header-right-section">
											<div id="header-right-sidebar" class="clearfix">
							<aside id="colormag_728x90_advertisement_widget-2" class="widget widget_728x90_advertisement clearfix">
		<div class="advertisement_728x90">
		<div class="advertisement-content"><a href="https://appdindin.com.br/wp/wp-content/uploads/2017/11/testecapa2.png" class="single_ad_728x90" target="_blank" rel="nofollow">
                                    <img src="https://appdindin.com.br/wp/wp-content/uploads/2017/11/testecapa2.png" width="728" height="90" alt="">
                           </a></div>		</div>
		</aside>						</div>
										</div><!-- #header-right-section -->

			</div><!-- #header-text-nav-wrap -->

		</div><!-- .inner-wrap -->

		
					
					
		<nav id="site-navigation" class="main-navigation clearfix" role="navigation">
			<div class="inner-wrap clearfix">
				
					<div class="home-icon">
						<a href="https://appdindin.com.br/blog/" title="DinDin"><i class="fa fa-home"></i></a>
					</div>

					
				<h4 class="menu-toggle"></h4>
				<div class="menu-primary-container"><ul id="menu-primary" class="menu"><li id="menu-item-258" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-258"><a title="Download This Theme" href="https://www.appdindin.com.br/">DINDIN</a></li>
<li id="menu-item-338" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-338"><a href="https://www.appdindin.com.br/">download</a>
<ul class="sub-menu">
	<li id="menu-item-352" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-352"><a href="https://itunes.apple.com/br/app/dindin/id1163797921">iOS</a></li>
	<li id="menu-item-351" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-351"><a href="https://play.google.com/store/apps/details?id=dindinapp.alphacode.com.br&#038;hl=pt_BR">Android</a></li>
</ul>
</li>
</ul></div>
				
									<i class="fa fa-search search-top"></i>
					<div class="search-form-top">
						<form action="https://appdindin.com.br/blog/" class="search-form searchform clearfix" method="get">
   <div class="search-wrap">
      <input type="text" placeholder="Pesquisar" class="s field" name="s">
      <button class="search-icon" type="submit"></button>
   </div>
</form><!-- .searchform -->					</div>
							</div>
		</nav>

		
				</div><!-- #header-text-nav-container -->

				
			</header>
									<div id="main" class="clearfix">
				<div class="inner-wrap clearfix">
	
	<div id="primary">
		<div id="content" class="clearfix">
			<section class="error-404 not-found">
				<div class="page-content">

					<aside id="colormag_728x90_advertisement_widget-4" class="widget widget_728x90_advertisement clearfix">
		<div class="advertisement_728x90">
		<div class="advertisement-content"><a href="http://themegrill.com" class="single_ad_728x90" target="_blank" rel="nofollow">
                                    <img src="http://demo.themegrill.com/colormag/wp-content/uploads/sites/20/2015/03/728x90.png" width="728" height="90" alt="">
                           </a></div>		</div>
		</aside>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->
		</div><!-- #content -->
	</div><!-- #primary -->

	
<div id="secondary">
			
		<aside id="colormag_featured_posts_vertical_widget-1" class="widget widget_featured_posts widget_featured_posts_vertical widget_featured_meta clearfix">		<h3 class="widget-title" style="border-bottom-color:#a38a6d;"><span style="background-color:#a38a6d;">News</span></h3>					</aside>
	</div>
	

</div><!-- .inner-wrap -->
</div><!-- #main -->




<footer id="colophon" class="clearfix ">
	
<div class="footer-widgets-wrapper">
	<div class="inner-wrap">
		<div class="footer-widgets-area clearfix">
         <div class="tg-footer-main-widget">
   			<div class="tg-first-footer-widget">
   				<aside id="text-2" class="widget widget_text clearfix"><h3 class="widget-title"><span>Sobre o DinDin</span></h3>			<div class="textwidget"><a title="DinDin" href="https://appdindin.com.br/blog/"><img alt="DinDin" src="http://ap.imagensbrasil.org/images/2017/11/07/sfun.png"></a><br/>O DinDin possibilita que você pague e cobre qualquer pessoa de forma fácil, rápida e sem inconveniências, com seu cartão de crédito. Explore seu feed, descubra e dê risadas com as movimentações de seus amigos!</div>
		</aside>   			</div>
         </div>
         <div class="tg-footer-other-widgets">
   			<div class="tg-second-footer-widget">
   				<aside id="text-3" class="widget widget_text clearfix"><h3 class="widget-title"><span>Links Úteis</span></h3>			<div class="textwidget"><ul>
<li> <a href="https://www.appdindin.com.br/">Site DinDin</a></li>
<li> <a href="https://www.facebook.com/aplicativodindin">Facebook</a></li>
<li> <a href="https://www.instagram.com/appdindin">Instagram</a></li>
<li> <a href="https://itunes.apple.com/br/app/dindin/id1163797921">Download iOS</a></li>
<li> <a href="https://play.google.com/store/apps/details?id=dindinapp.alphacode.com.br&hl=pt_BR">Download Android</a></li>
<li> <a href="https://appdindin.com.br/blog/">Blog</a></li>
</ul></div>
		</aside>   			</div>
            <div class="tg-third-footer-widget">
                           </div>
            <div class="tg-fourth-footer-widget">
                           </div>
         </div>
		</div>
	</div>
</div>	<div class="footer-socket-wrapper clearfix">
		<div class="inner-wrap">
			<div class="footer-socket-area">
				<div class="footer-socket-right-section">
							<div class="social-links clearfix">
			<ul>
				<li><a href="https://www.facebook.com/aplicativodindin/" target="_blank"><i class="fa fa-facebook"></i></a></li><li><a href="https://twitter.com/appdindin" target="_blank"><i class="fa fa-twitter"></i></a></li><li><a href="https://www.appdindin.com.br/" target="_blank"><i class="fa fa-google mais"></i></a></li><li><a href="https://www.instagram.com/appdindin/" target="_blank"><i class="fa fa-instagram"></i></a></li><li><a href="https://www.appdindin.com.br/" target="_blank"><i class="fa fa-pinterest"></i></a></li><li><a href="https://www.appdindin.com.br/" target="_blank"><i class="fa fa-youtube"></i></a></li>			</ul>
		</div><!-- .social-links -->
						</div>
				<div class="footer-socket-left-sectoin">
					<div class="copyright">Copyright &copy; 2017 <a href="https://appdindin.com.br/blog/" title="DinDin" ><span>DinDin</span></a>. Todos os direitos reservados.<br>Tema: ColorMag por <a href="https://themegrill.com/themes/colormag" target="_blank" title="ThemeGrill" rel="designer"><span>ThemeGrill</span></a>.  Powered by <a href="https://wordpress.org" target="_blank" title="WordPress"><span>WordPress</span></a>.</div>				</div>
			</div>
		</div>
	</div>
</footer>

<a href="#masthead" id="scroll-up"><i class="fa fa-chevron-up"></i></a>
</div><!-- #page -->
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/jquery.bxslider.min.js?ver=4.2.10'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/colormag-slider-setting.js?ver=4.9.1'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/navigation.js?ver=4.9.1'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/news-ticker/jquery.newsTicker.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/news-ticker/ticker-setting.js?ver=20150304'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/sticky/jquery.sticky.js?ver=20150309'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/sticky/sticky-setting.js?ver=20150309'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/magnific-popup/jquery.magnific-popup.min.js?ver=20150310'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/magnific-popup/image-popup-setting.js?ver=20150310'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/fitvids/jquery.fitvids.js?ver=20150311'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-content/themes/colormag/js/fitvids/fitvids-setting.js?ver=20150311'></script>
<script type='text/javascript' src='https://appdindin.com.br/wp/wp-includes/js/wp-embed.min.js?ver=4.9.1'></script>
</body>
</html>